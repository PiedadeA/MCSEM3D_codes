clear all

fb  = load('fort.222');
matr= load('fort.444');

%fb = matr;

%fb  = log10(abs(fb));
%matr = log10(abs(matr));

for i = 1:length(fb(1,:))
    figure
	subplot(2,1,1)
    plot( fb(:,i),'-r' )
        hold on
    plot( matr(:,i),'--b' )
	grid;
    legend('Fb','Mat')
    hold off
    
    Err = abs( (fb(:,i) - matr(:,i)) );
    %Err = 100.*abs( (fb(:,i) - matr(:,i))./fb(:,i) );
    
    subplot(2,1,2)
    plot(Err,'r')
    grid
    legend('Erro abs')
end


clear all

dd  = load('Ex_het.dat');
dds = load('Ex_prim.dat');
qrc = load('dados2.dat');
inf = load('dados1.dat');

nf  = inf(1);
npf = inf(2);

% figure 
% plot(dd,'r')
% hold on
% plot(dds,'b')
% hold off

%==================================================================
%==== Dizer aqui qual frequencia, perfil e fonte(receptor) quer === 
%==== visualizar                                                ===

for l = 1:5 % numero de fontes

Fr = 1; Per = 1; Rec = l;

%==================================================================
%==================================================================

sd = sum(qrc);

c = 0;

for i = 1:Fr;
    
    if i < Fr;
        
        for j = 1:npf;

            for k = 1:inf(2+j);
        		c = c + 1;
            end
            
        end
        
    else    

        for j = 1:Per;
    	
            if j < Per;
                for k = 1:inf(2+j);
                	c = c + 1;
                end
            else
                for k = 1:Rec;
                    c = c + 1;
                end
            end
            
        end
                
    end
    
end

tm = 15;
lw = 2;

figure

if c == 1
% subplot(2,1,1)
  plot( dd(1:qrc(c)),'r--','linewidth',lw )
  hold on
  plot( dds(1:qrc(c)),'b','linewidth',lw )
  set(gca,'fontSize',tm)
  xlabel(' N pontos ','fontsize',tm,'Interpreter','Latex');
  ylabel('$$ Log_{10} \vert E_{x} \vert \ (V/m) $$','fontsize',tm,'Interpreter','Latex');
  legend('HC','NHC');
  grid;
  hold off
% subplot(2,1,2)
%  plot( dd( sd + 1 : sd + qrc(c) ),'r' )
%  hold on
%  plot( dds( sd + 1 : sd + qrc(c) ),'b' )
%  xlabel(' N pontos ','fontsize',tm,'Interpreter','Latex');
%  ylabel('$$ \phi_{E_{x}} \ (rad) $$','fontsize',tm,'Interpreter','Latex');
%  legend('HC','NHC',1);
%  grid;
%  hold off
else
% subplot(2,1,1)
  plot( dd( sum(qrc(1:c-1))+1 : sum(qrc(1:c)) ),'r--','linewidth',lw )
  hold on
  plot( dds( sum(qrc(1:c-1))+1 : sum(qrc(1:c)) ),'b','linewidth',lw )
  set(gca,'fontSize',tm)
  xlabel(' N pontos ','fontsize',tm,'Interpreter','Latex');
  ylabel('$$ Log_{10} \vert E_{x} \vert \ (V/m) $$','fontsize',tm,'Interpreter','Latex');
  legend('HC','NHC');
  grid;
  hold off
% subplot(2,1,2)
%  plot( dd( sum(qrc(1:c-1))+1 + sd : sum(qrc(1:c)) + sd ),'r' )
%  hold on
%  plot( dds( sum(qrc(1:c-1))+1 + sd : sum(qrc(1:c)) + sd ),'b' )
%  xlabel(' N pontos ','fontsize',tm,'Interpreter','Latex');
%  ylabel('$$ \phi_{E_{x}} \ (rad) $$','fontsize',tm,'Interpreter','Latex');
%  legend('HC','NHC',1);
%  grid;
%  hold off
end

end

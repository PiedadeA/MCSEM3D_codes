'''
       Visualizador das curvas Mcsem 3D
Autor: Anderson Almeida. 23/05/2019   
'''

import numpy as np
import matplotlib.pyplot as plt
import math as ma

cEs = open('Ex_het.dat','r')
#cEp = open('Ex_prim2.dat','r')
cEp = open('RespostaBipolo.dat','r')

ndata = 51

#--

Et = np.zeros(ndata,np.float)
Ep = np.zeros(ndata,np.float)

x  = np.zeros(ndata,np.float)

#--

xi = -3000.0
xf =  3000.0
dx = (xf-xi)/(ndata-1)
for i in range(ndata):
    x[i] = xi + i * dx

#--

m = -1
for i in cEs:
    m += 1
    rw = i.split()
    Et[m] = np.float(rw[1])

#--

m = -1
for i in cEp:
    m += 1
    rw = i.split()
    Ep[m] = np.float(rw[9])

#--

lw = 1.2

plt.figure(figsize=(7.5,5.1))

plt.subplot(2,1,1)

plt.plot(x,Ep,'-.b',label= r'$ Zdanov $',linewidth=lw)
plt.plot(x,Et,'-.r',label= r'$ Nodal $',linewidth=lw)
plt.ylabel('Re$\{E_x^s\}$ (V/m)')
#plt.xlabel('x (m)')
plt.legend()
plt.grid()

plt.subplot(2,1,2)

#Ep = np.log10(abs(Ep))
#Et = np.log10(abs(Et))

plt.plot(x,abs((Ep-Et)),'-.r',label= r'$ Err \% $',linewidth=lw)
plt.ylabel('|Erro|')
#plt.plot(x,100.0*abs((Ep-Et)/Ep),'-.r',label= r'$ Error \% $',linewidth=lw)
#plt.ylabel('Error %')
#plt.yscale('log')
plt.xlabel('x (m)')
#plt.legend()
plt.grid()

plt.show()


'''
       Visualizador das curvas Mcsem 3D
Autor: Anderson Almeida. 23/05/2019   
'''

import numpy as np
import matplotlib.pyplot as plt
import math as ma

ndata = 80
Tx    = 1
nt    = 1

#--

Etd = np.zeros(nt*ndata,np.float)
#Et = np.zeros(nt*ndata,np.float)
#Ep = np.zeros(ndata,np.float)

Etid = np.zeros(nt*ndata,np.float)
#Eti = np.zeros(nt*ndata,np.float)
#Epi = np.zeros(ndata,np.float)

x  = np.zeros(ndata,np.float)

#--

xi = -3000.0
xf =  3000.0
dx = (xf-xi)/(ndata-1)
for i in range(ndata):
    x[i] = xi + i * dx

#--

MEDIUM_SIZE = 12

#--

q = 0
for l in range(3):

	cEd = open('campo_E_aresta.dat','r')
#	cEs = open('E_het.dat','r')
#	cEp = open('campo_Ex_aresta4.dat','r')

	ir = q
	ii = q+1

	#print(ir,ii)

	m = -1
	for i in cEd:
	    m += 1
	    rw = i.split()
	    Etd[m]  = np.float(rw[ir])
	    Etid[m] = np.float(rw[ii])
	
#	m = -1
#	for i in cEs:
#	    m += 1
#	    rw = i.split()
#	    Et[m]  = np.float(rw[ir])
#	    Eti[m] = np.float(rw[ii])

#--

#	m = -1
#	for i in cEp:
#	    m += 1
#	    rw = i.split()
#	    Ep[m] = np.float(rw[ir])
#	    Epi[m] = np.float(rw[ii])

#--

	lw = 2.0

	plt.figure(figsize=(8.5,5.2))

#	plt.subplot(2,1,1)


#	plt.plot(x,Ep,'-sk',label= r'$ re-Isop $',linewidth=lw)
#	plt.plot(x,Et[(Tx-1)*ndata:Tx*ndata],'-.k',label= r'$ re-Nod $',linewidth=lw,mfc='None')
	plt.plot(x,Etd[(Tx-1)*ndata:Tx*ndata],'-.r',label= r'$ re-Vet $',linewidth=lw,mfc='None')
	plt.rc('font', size=MEDIUM_SIZE)

	if q == 0 : plt.title(r'$E_x$ Field')
	if q == 2 : plt.title(r'$E_y$ Field')
	if q == 4 : plt.title(r'$E_z$ Field')

#	if l == 0 : plt.ylabel('Re$\{E_x^s\}$ (V/m)')
#	if l == 1 : plt.ylabel('Re$\{E_y^s\}$ (V/m)')
#	if l == 2 : plt.ylabel('Re$\{E_z^s\}$ (V/m)')
	#plt.xlabel('x (m)')
	#plt.legend()
	#plt.grid()

#	plt.subplot(2,1,2)

#	plt.plot(x,Epi,'-sb',label= r'$ im-Isoparam $',linewidth=lw)
#	plt.plot(x,Eti[(Tx-1)*ndata:Tx*ndata],'-.b',label= r'$ im-Nod $',linewidth=lw,mfc='None')
	plt.plot(x,Etid[(Tx-1)*ndata:Tx*ndata],'-.g',label= r'$ im-Vet $',linewidth=lw,mfc='None')
	plt.rc('font', size=MEDIUM_SIZE)

#	if l == 0 : plt.ylabel('Im$\{E_x^s\}$ (V/m)')
#	if l == 1 : plt.ylabel('Im$\{E_y^s\}$ (V/m)')
#	if l == 2 : plt.ylabel('Im$\{E_z^s\}$ (V/m)')
	plt.xlabel('x (m)')
	plt.legend()
	plt.grid()

	##plt.plot(x,abs((Ep-Et)),'-.r',label= r'$ Err \% $',linewidth=lw)
	##plt.ylabel('|Erro|')
	#plt.plot(x,100.0*abs((Ep-Et)/Ep),'-.r',label= r'$ Error \% $',linewidth=lw)
	#plt.ylabel('Error %')
	##plt.yscale('log')
	##plt.xlabel('x (m)')
	##plt.legend()
	##plt.grid()

	q += 2

	cEd.close()
	#cEs.close()
	#cEp.close()

plt.show()

#SMALL_SIZE  = 8
#MEDIUM_SIZE = 10
#BIGGER_SIZE = 12

#plt.rc('font', size=SMALL_SIZE)          # controls default text sizes
#plt.rc('axes', titlesize=SMALL_SIZE)     # fontsize of the axes title
#plt.rc('axes', labelsize=MEDIUM_SIZE)    # fontsize of the x and y labels
#plt.rc('xtick', labelsize=SMALL_SIZE)    # fontsize of the tick labels
#plt.rc('ytick', labelsize=SMALL_SIZE)    # fontsize of the tick labels
#plt.rc('legend', fontsize=SMALL_SIZE)    # legend fontsize
#plt.rc('figure', titlesize=BIGGER_SIZE)  # fontsize of the figure title


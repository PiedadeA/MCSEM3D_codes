clear all
close all
clc

tf = 15;
Ms = 1; 

ja = load('fort.1010');
ia = load('fort.1011');
rv = load('fort.1012');
iv = load('fort.1013');

x  = ja;
N  = length(ia)-1;
nz = N + 2 *(length(x)-N);

cn = 0;
for i = 1:N
    for j = ia(i):ia(i+1)-1
           cn = cn + 1;
        y(cn) = (N+1)-i;
    end    
end

% figure
% plot(x,y,'.b','Linewidth',1,'MarkerSize',Ms)
% hold

 cn = 0;
 for i = 1:N
     for j = ia(i):ia(i+1)-1
            cn = cn + 1;
         x(cn) = i ;
         y(cn) = (N+1)-ja(j);
     end    
 end
 
% plot(x,y,'.b','Linewidth',1,'MarkerSize',Ms)
% set(gca,'Linewidth',1,'FontSize',tf,'Fontname','Inconsolata')
% xlabel(sprintf('nnz = %d ',nz),'FontSize',tf,'Fontname','Inconsolata')
% xlim([0 N+1])
% ylim([0 N+1])

%---- Criando uma matriz sparsa ----

%jja = ja;
%iia = ja;
%val = ja;

cn = 0;
for i = 1:N
    for j = ia(i):ia(i+1)-1
           cn = cn + 1;
      iia(cn) = i;
      jja(cn) = ja(j);
      val(cn) = (rv(ja(j)) + 1j*iv(ja(j)));
      %if(ja(j)==i)
      %   val(cn) = (rv(ja(j)) + 1j*iv(ja(j)));  
      %else
      %   val(cn) = (rv(ja(j)) + 1j*iv(ja(j)));
      %end      
    end    
end
% for i = 1:N
%     for j = ia(i):ia(i+1)-1
%         if(ja(j) ~= i)
%            cn = cn + 1;
%            iia(cn) = ja(j);
%            jja(cn) = i;
%            val(cn) = rv(ja(j)) + 1j*iv(ja(j));
%         end    
%     end
% end

A = sparse(iia,jja,val);

figure
spy(A)
set(gca,'Linewidth',1,'FontSize',tf,'Fontname','Inconsolata')

 figure
 d = dissect(A);
 %d = amd(A);
 Ren = sparse(A(d,d));
 spy(Ren,'.b',1)
 title(sprintf('Nested Dissection Reordering'))
 set(gca,'Linewidth',1,'FontSize',tf,'Fontname','Inconsolata')

% figure
% Le = sparse(chol(Ren(d,d),'Lower'));
% spy(Le,'.b',1)
% title(sprintf('Lower Cholesky Factorization'))
% set(gca,'Linewidth',1,'FontSize',tf,'Fontname','Inconsolata')

%----

'''
       Visualizador das curvas Mcsem 3D
Autor: Anderson Almeida. 23/05/2019   
'''

import numpy as np
import matplotlib.pyplot as plt
import math as ma

cEs = open('Ex_het.dat','r')
cEp = open('Ex_prim.dat','r')

ndata = 160

#--

Et = np.zeros(ndata,np.float)
Ep = np.zeros(ndata,np.float)

ndta  = ndata
ndata = int(ndata/2)

x  = np.zeros(ndata,np.float)

#--

xi = -3000.0
xf =  3000.0
dx = (xf-xi)/(ndata-1)
for i in range(ndata):
    x[i] = xi + i * dx

ndata = ndta

#--

m = -1
for i in cEs:
    m += 1
    rw = i.split()
    Et[m] = np.float(rw[0])

#--

m = -1
for i in cEp:
    m += 1
    rw = i.split()
    Ep[m] = np.float(rw[0])

#--

lw = 1.2

ii = 0
jj = int(ndata/2)

plt.figure(figsize=(7.5,5.1))

plt.subplot(2,1,1)

plt.plot(x,Ep[ii:jj],'-.b',label= r'$ 1D $',linewidth=lw)
plt.plot(x,Et[ii:jj],'-.r',label= r'$ 3D $',linewidth=lw)
plt.title('Inline Field')
plt.ylabel(' $ Log_{10}|E_x| $ (V/m)')
plt.xlabel('x (m)')
plt.legend()
plt.grid()

plt.subplot(2,1,2)

ii = int(ndata/2)
jj = ndata

plt.plot(x,Ep[ii:jj],'-.b',label= r'$ 1D $',linewidth=lw)
plt.plot(x,Et[ii:jj],'-.r',label= r'$ 3D $',linewidth=lw)
plt.title('Inline Field')
plt.ylabel(' $ \phi $ (rad)')
plt.xlabel('x (m)')
plt.legend()
plt.grid()

#Ep = np.log10(abs(Ep))
#Et = np.log10(abs(Et))

#plt.plot(x,abs((Ep-Et)),'-.r',label= r'$ Err \% $',linewidth=lw)
#plt.ylabel('|Erro|')
#plt.plot(x,100.0*abs((Ep-Et)/Ep),'-.r',label= r'$ Error \% $',linewidth=lw)
#plt.ylabel('Error %')
#plt.yscale('log')
#plt.xlabel('x (m)')
#plt.legend()
#plt.grid()

plt.show()


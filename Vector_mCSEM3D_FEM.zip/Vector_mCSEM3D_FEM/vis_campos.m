clear all

dd  = load('Ex_het.dat');
dds = load('Ex_prim.dat');
qrc = load('dados2.dat');
inf = load('dados1.dat');
ofs = load('offsets.dat');

m  = length(dd)/2;
%-
dd(1:m) = log10(exp(dd(1:m)));
dds(1:m) = log10(exp(dds(1:m)));
dd(m+1:2*m) = dd(m+1:2*m);
dds(m+1:2*m) = dds(m+1:2*m);
%-
nf  = inf(1);
npf = inf(2);
%-
%==================================================================
%==== Dizer aqui qual frequencia, perfil e fonte(receptor) quer === 
%==== visualizar                                                ===
%-
for l = 1:1 % numero de fontes

Fr = 1; Per = 1; Rec = l;

sd = sum(qrc);

c = 0;

for i = 1:Fr
    
    if i < Fr
        
        for j = 1:npf

            for k = 1:inf(2+j)
        		c = c + 1;
            end
            
        end
        
    else    

        for j = 1:Per
    	
            if j < Per
                for k = 1:inf(2+j)
                	c = c + 1;
                end
            else
                for k = 1:Rec
                    c = c + 1;
                end
            end
            
        end
                
    end
    
end

tm = 10;
lw = 1;

figure

if c == 1
 subplot(2,1,1)
  plot( ofs(1:qrc(c)), dd(1:qrc(c)),'r-.','linewidth',lw )
  hold on
  plot( ofs(1:qrc(c)), dds(1:qrc(c)),'b','linewidth',lw )
  set(gca,'fontSize',tm)
  xlabel(' Offset (m) ','fontsize',tm,'Interpreter','Latex');
  ylabel('$$ Log_{10} \vert E_{x} \vert \ (V/m) $$','fontsize',tm,'Interpreter','Latex');
  legend('HC','NHC');
  grid;
  hold off
subplot(2,1,2)
 plot( ofs( sd + 1 : sd + qrc(c) ), dd( sd + 1 : sd + qrc(c) ),'r','linewidth',lw )
 hold on
 plot( ofs( sd + 1 : sd + qrc(c) ), dds( sd + 1 : sd + qrc(c) ),'b','linewidth',lw )
 set(gca,'fontSize',tm)
 xlabel(' Offset (m) ','fontsize',tm,'Interpreter','Latex');
 ylabel('$$ \phi_{E_{x}} \ (rad) $$','fontsize',tm,'Interpreter','Latex');
 legend('HC','NHC');
 grid;
 hold off
else
 subplot(2,1,1)
  plot( ofs( sum(qrc(1:c-1))+1 : sum(qrc(1:c)) ), dd( sum(qrc(1:c-1))+1 : sum(qrc(1:c)) ),'r-.','linewidth',lw )
  hold on
  plot( ofs( sum(qrc(1:c-1))+1 : sum(qrc(1:c)) ) ,dds( sum(qrc(1:c-1))+1 : sum(qrc(1:c)) ),'b','linewidth',lw )
  set(gca,'fontSize',tm)
  xlabel(' Offset (m) ','fontsize',tm,'Interpreter','Latex');
  ylabel('$$ Log_{10} \vert E_{x} \vert \ (V/m) $$','fontsize',tm,'Interpreter','Latex');
  legend('HC','NHC');
  grid;
  hold off
subplot(2,1,2)
 plot( ofs( sum(qrc(1:c-1))+1 + sd : sum(qrc(1:c)) + sd ) , dd( sum(qrc(1:c-1))+1 + sd : sum(qrc(1:c)) + sd ),'r','linewidth',lw )
 hold on
 plot( ofs( sum(qrc(1:c-1))+1 + sd : sum(qrc(1:c)) + sd ), dds( sum(qrc(1:c-1))+1 + sd : sum(qrc(1:c)) + sd ),'b','linewidth',lw )
 set(gca,'fontSize',tm)
 xlabel(' Offset (m) ','fontsize',tm,'Interpreter','Latex');
 ylabel('$$ \phi_{E_{x}} \ (rad) $$','fontsize',tm,'Interpreter','Latex');
 legend('HC','NHC');
 grid;
 hold off
end

end

'''
       Visualizador das curvas Mcsem 3D, jacobiana
Autor: Anderson Almeida. 23/05/2019   
'''

import numpy as np
import matplotlib.pyplot as plt
import math as ma

#--
cEs = open('jacfbt.dat','r')
#--
m = 0
for i in cEs:
    m += 1

ndata = m
#--

cEd = open('jacmat.dat','r')
#cEp = open('jacmatmqp.dat','r')
cEs = open('jacfbt.dat','r')

#--

Ed = np.zeros(ndata,np.float)
Et = np.zeros(ndata,np.float)
Ep = np.zeros(ndata,np.float)

x  = np.zeros(ndata,np.float)

#--

xi = -3000.0
xf =  3000.0
dx = (xf-xi)/(ndata-1)
for i in range(ndata):
    x[i] = xi + i * dx

#--

m = -1
for i in cEs:
    m += 1
    rw = i.split()
    Et[m] = np.float(rw[0])

#--

#m = -1
#for i in cEp:
#    m += 1
#    rw = i.split()
#    Ep[m] = np.float(rw[0])

#--

m = -1
for i in cEd:
    m += 1
    rw = i.split()
    Ed[m] = np.float(rw[0])

#--

SZ = 25
lw = 2

plt.figure(figsize=(14,7))

#plt.subplot(2,1,1)

plt.rcParams.update({'font.size': SZ})

#plt.plot(x,(Ep),'-sb',label= 'Auto Adjunto - MQP',mfc='None',Linewidth=lw)
plt.plot(x,(Ed),'-or',label= 'Auto Adjunto - FBS',mfc='None',Linewidth=lw)
plt.plot(x,(Et),'-k',label= 'Pertubativo',mfc='None',Linewidth=lw)

plt.ylabel(r'$ \frac{ \partial \ Re \{ E^s_x \} }{ \partial \ ( Log_{10}\ \rho) } $')
plt.xlabel('x (m)')
plt.legend()
plt.grid()


plt.show()

